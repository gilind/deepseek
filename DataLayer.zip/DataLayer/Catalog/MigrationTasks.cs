﻿namespace Ru.DataLayer.Catalog
{
    public class MigrationTasks
    {
        public const string Migrate = "migrate";
        public const string Rollback = "rollback";
        public const string RollbackAll = "rollback:all";
    }
}