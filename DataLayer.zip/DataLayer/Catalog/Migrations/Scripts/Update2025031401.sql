﻿UPDATE CouplingTypes
	SET Size1Name = N'Диаметр'
	WHERE UPPER(Name) = N'ХОМУТ';
GO
