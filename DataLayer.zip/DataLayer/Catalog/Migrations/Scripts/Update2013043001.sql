﻿
alter table ArmatureTypes
	add Image [varbinary]  (max)
GO