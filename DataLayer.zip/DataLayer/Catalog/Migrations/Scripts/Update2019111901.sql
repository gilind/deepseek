﻿ALTER TABLE CableBracings ADD BracingType int NOT NULL DEFAULT(0) 
GO