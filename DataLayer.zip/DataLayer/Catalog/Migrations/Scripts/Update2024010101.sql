﻿ALTER TABLE CableBracings ADD DistanceToIsolator float NOT NULL DEFAULT(0.0)
GO