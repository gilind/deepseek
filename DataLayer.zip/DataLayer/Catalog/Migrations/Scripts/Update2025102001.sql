﻿ALTER TABLE Armatures ADD ReserveRateIsZero bit NOT NULL DEFAULT(0)
GO

ALTER TABLE Pylons ADD Flexible bit NOT NULL DEFAULT(0)
GO

