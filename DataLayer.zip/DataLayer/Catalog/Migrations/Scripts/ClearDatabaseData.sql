﻿USE [ConvertedElectricalDB]
GO
DELETE FROM [dbo].[Slashing_Zones]
GO
DELETE FROM [dbo].[Slashing_WoodTypes]
GO
DELETE FROM [dbo].[Slashing_ForestYield]
GO
DELETE FROM [dbo].[MigSharp]
GO
DELETE FROM [dbo].[Configuration]
GO
DELETE FROM [dbo].[SectionCornerSets]
GO
DELETE FROM [dbo].[SectionCorners]
GO
DELETE FROM [dbo].[Soils]
GO
DELETE FROM [dbo].[ConstructionGroups]
GO
DELETE FROM [dbo].[PylonConfigurationsEquipmentConfigurations]
GO
DELETE FROM [dbo].[PylonConfigurationsClampTypes]
GO
DELETE FROM [dbo].[EquipmentConfigurationClampTypes]
GO
DELETE FROM [dbo].[Allotment_Allotments]
GO
DELETE FROM [dbo].[Allotment_Fixations]
GO
DELETE FROM [dbo].[Clamp_Clamps]
GO
DELETE FROM [dbo].[Clamp_Types]
GO
DELETE FROM [dbo].[Wires]
GO
DELETE FROM [dbo].[PylonSections]
GO
DELETE FROM [dbo].[VolumeTerms]
GO
DELETE FROM [dbo].[LandTypes]
GO
DELETE FROM [dbo].[Foundation_Configurations]
GO
DELETE FROM [dbo].[Foundation_Foundations]
GO
DELETE FROM [dbo].[Foundation_Fixation]
GO
DELETE FROM [dbo].[Foundation_ConcreteTypes]
GO
DELETE FROM [dbo].[Foundation_Categories]
GO
DELETE FROM [dbo].[PylonConfigurationArmatures]
GO
DELETE FROM [dbo].[PylonConfigurations]
GO
DELETE FROM [dbo].[Pylons]
GO
DELETE FROM [dbo].[Factories]
GO
DELETE FROM [dbo].[EquipmentConfigurationsArmatures]
GO
DELETE FROM [dbo].[EquipmentConfigurations]
GO
DELETE FROM [dbo].[Equipments]
GO
DELETE FROM [dbo].[CableBracingConfigurations]
GO
DELETE FROM [dbo].[CableBracings]
GO
DELETE FROM [dbo].[Armatures]
GO
DELETE FROM [dbo].[TypeProjects]
GO
DELETE FROM [dbo].[ArmatureTypes]
GO
