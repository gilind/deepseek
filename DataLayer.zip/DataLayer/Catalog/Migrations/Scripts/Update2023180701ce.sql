ALTER TABLE CableBracings ADD ChainsIsolatorCount int NOT NULL DEFAULT(0)
GO
