﻿ALTER TABLE Pylons ADD ProductClassification NVARCHAR(255) NULL
GO
