﻿/****** Object:  Table [dbo].[Configuration]    Script Date: 04/21/2012 04:05:35 ******/
INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'80aaa2ec-540e-4883-a98b-0aead37c59c3', N'RussianReserveRateArmatures', N'2');
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'73f61b24-12f0-42a9-bdcf-417b75bb2516', N'ImportReserveRateArmatures', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'bb9cf657-6008-4adf-b4f6-695b8fbab647', N'RussianReserveRatePorcelainIsolators', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'f41bbc44-7af0-4507-a1ba-84825f81a08a', N'ImportReserveRatePorcelainIsolators', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'c5aa295a-a04f-4c98-8677-8859a24ad4aa', N'RussianReserveRateGlassIsolators', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'd82ccc54-d7ea-4627-9471-acb71332bfa8', N'ImportReserveRateGlassIsolators', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'71425026-b8d6-4e9e-a602-ba2154632c61', N'RussianReserveRatePolymerIsolators', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'e55c1e0f-e988-4665-b079-c60f0d5e9fbb', N'ImportReserveRatePolymerIsolators', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'91446c26-1b6d-4f5a-8fa1-c8e26d31724e', N'RussianReserveRateThermiteBullets', N'25')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'96b2b9c9-fcf0-4031-a5ec-cd3c7b5646d7', N'ImportReserveRateThermiteBullets', N'25')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'635500f2-e233-40ec-b97b-cf1f19c1abb3', N'RussianReserveRateThermiteMatches', N'25')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'3c004217-a100-4cc5-99ce-d8a669843025', N'ImportReserveRateThermiteMatches', N'25')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'6d5478b6-45fd-403b-803e-dcef33d7f0b0', N'RussianReserveRateWires', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'352fbd2d-c31a-4dbb-85a5-e045ece59ca9', N'ImportReserveRateWires', N'5')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'25a54370-8783-49c4-945f-f5213be0d4f4', N'RussianReserveRateRopes', N'3')
GO

INSERT [Configuration] ([ID], [Key], [Value]) VALUES (N'16a521fe-5d3a-42a0-9f3a-f7c83390acfb', N'ImportReserveRateRopes', N'3')