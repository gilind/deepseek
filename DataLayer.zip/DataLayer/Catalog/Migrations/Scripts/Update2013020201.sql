﻿alter table CableBracings     
	add IsolatorLength [float]
GO

alter table CableBracings 
	add ViewCount [int]
GO

alter table CableBracings
	add Orientation [bit]
GO

alter table CableBracings
	add ExpandPlane [bit]
GO