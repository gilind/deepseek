﻿
alter table ArmatureTypes
	add Image [image]
GO