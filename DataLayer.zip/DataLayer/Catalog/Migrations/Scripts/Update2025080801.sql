﻿ALTER TABLE Pylons ADD WireRehangingOffsetMiddleLeftTraverse float NOT NULL DEFAULT(0.0)
GO

ALTER TABLE Pylons ADD WireRehangingOffsetMiddleRightTraverse float NOT NULL DEFAULT(0.0)
GO
