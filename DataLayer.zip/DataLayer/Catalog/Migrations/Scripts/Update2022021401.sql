ALTER TABLE CableBracingArmatures ADD IsDrawable bit NOT NULL DEFAULT(1)
GO
